package com.example.swe_206;

public class Student extends Participant {
	private String email;
	
}

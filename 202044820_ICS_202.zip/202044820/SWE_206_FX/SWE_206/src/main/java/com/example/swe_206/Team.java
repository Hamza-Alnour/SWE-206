package com.example.swe_206;

import java.util.ArrayList;

public class Team extends Participant {
	private int maxTeamSize;
	private ArrayList<Student> members;
}
